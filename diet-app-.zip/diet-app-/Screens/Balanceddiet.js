import React, { Component } from 'react';
import {
  Text,
  View,
  StyleSheet,
  TouchableOpacity,
  Image,
  ImageBackground,
  SafeAreaView,
  Platform,
  StatusBar,
} from 'react-native';
import { NavigationContainer } from "@react-navigation/native";
import DrawerNavigator from "../Navigation/DrawerNavigatior";

import BalanceddietScreen from './Balanceddiet';
import MyDietScreen from './MyDiet';
import ProductsScreen from './Products';


export default class Balanceddiet extends Component {
  render() {
    return (
         <View style={styles.container}>
        <SafeAreaView style={styles.droidSafeArea} />
        <ImageBackground source={require("../assets/51c95284e624c47b964041f6daaf28fd.jpg")}
        style={styles.backgroundImage}>
        <View style={styles.titleBar}>
          <Text style={styles.titleText}>DIET APP </Text>
        </View>
        
        <TouchableOpacity style={styles.options}
          onPress={() => this.props.navigation.navigate('Products')}>
          <Text style={styles.optionsText}> Products </Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.options}
          onPress={() => this.props.navigation.navigate('MyDiet')}>
          <Text style={styles.optionsText}> My Diet </Text>
        </TouchableOpacity>
      </ImageBackground>
      </View>
     
    );
  }
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  droidSafeArea: {
    marginTop: Platform.OS === 'android' ? StatusBar.currentHeight : 10,
  },
  titleBar: {
    flex: 0.10,
    justifyContent: 'center',
    alignItems: 'center',
  },
  titleText: {
    fontSize: 35,
    marginTop:10,
    marginBottom:0,
    fontWeight: 'bold',
    color: 'green',
  },
  options:{
    flex:0.2,
    marginLeft:70,
    marginRight:70,
    marginTop:40,
    backgroundColor:'',
    borderRadius:0,
    borderWidth:0,
  },
  optionsText:{
    marginTop:10,
    fontSize:25,
   color:"white",
   fontWeight:"bold",
   alignSelf:"center",
  },
  backgroundImage:{
    flex:1,
    resizeMode:'cover'
  },
});
