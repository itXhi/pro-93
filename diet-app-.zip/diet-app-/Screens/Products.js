import React, { Component } from 'react';
import {
  Text,
  View,
  StyleSheet,
  TouchableOpacity,
  Image,
  ImageBackground,
  SafeAreaView,
} from 'react-native';
import { RFValue } from "react-native-responsive-fontsize";
import ReactNativeZoomableView from '@dudigital/react-native-zoomable-view/src/ReactNativeZoomableView';

export default class ProductsScreen extends Component{
 render(){
   return(
     <View style={{flex:1 , justifyContent:'center', alignItems: "center"}}>
      <ReactNativeZoomableView
          zoomEnabled={true}
            maxZoom={1.5}
            minZoom={0.5}
            zoomStep={0.25}
            initialZoom={0.9}
            bindToBorders={true}>
      <Image
       source={require("../assets/watermelon.png")}
       style={styles.image}
       ></Image>
       <Text></Text>
      <Image source={require("../assets/bellpepper.png")}
       style={styles.image}></Image>
       <Text></Text>
      <Image source={require("../assets/banana.png")}
       style={styles.image}></Image>
       <Text></Text>
      <Image source={require("../assets/apple.png")}
       style={styles.image}></Image>
         </ReactNativeZoomableView>    
     </View>
   )
 }

} 

const styles = StyleSheet.create({
 image:{
  
  width:290,
  height:100,

 }
});

