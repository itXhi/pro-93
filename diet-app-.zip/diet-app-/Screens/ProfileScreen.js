import * as React from 'react';
import {
  Text ,
  View,
  StyleSheet,
  ScrollView,
  TouchableHighlight,
  TouchableOpacity,
  Image,
  Platform,
  TextInput,
} from 'react-native';
import Ionicons from 'react-native-vector-icons/Ionicons';

export default class App extends React.Component {

  render() {
    return (
      <View>
        <ScrollView showsVerticalScrollIndicator={false}>
          <View
            style={{
              padding: 10,
              width: '100%',
              backgroundColor: '#000',
              height: 150,
            }}>
            <TouchableOpacity>
              <Image
                source={require('../assets/black.png')}
                style={{ width: 30, height: 30 }}></Image>
              <View></View>
              <View></View>
            </TouchableOpacity>
          </View>
          <View style={{ alignItems: 'center' }}>
            <Image
              source={require('../assets/Google-Logo-Clear-Background-5.png')}
              style={{
                width: 120,
                height: 160,
                borderRadius: 100,
                marginTop: -70,
              }}
            />
            <Text style={{ fontSize: 25, fontWeight: 'bold', padding: 10 }}>
              
            </Text>
            <TextInput
                onChangeText={description => this.setState({ description })}
                placeholder={"NAME:"}
                multiline={false}
                numberOfLines={10}
                placeholderTextColor="black"
              />
            <Text
              style={{
                fontSize: 25,
                fontWeight: 'bold',
                padding: 5,
                color: '#808080',
              }}>
              AGE : 15
            </Text>
              <TextInput
                onChangeText={description => this.setState({ description })}
                placeholder={"NAME:"}
                multiline={false}
                numberOfLines={10}
                placeholderTextColor="black"
              />
                <Text
              style={{
                fontSize: 25,
                fontWeight: 'bold',
                padding: 5,
                color: '#808080',
              }}>
              height:
            </Text>
                <Text
              style={{
                fontSize: 25,
                fontWeight: 'bold',
                padding: 5,
                color: '#808080',
              }}>
              Weight:
            </Text>
          </View>
        </ScrollView>
      </View>
    );
  }
}
