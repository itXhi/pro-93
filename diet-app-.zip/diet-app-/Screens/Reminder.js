
import React, { Component } from 'react';
import {
  Text,
  View,
  StyleSheet,
  TouchableOpacity,
  Image,
  ImageBackground,
  SafeAreaView,
} from 'react-native';
import * as Notifications from 'expo-notifications';

export default class MyDietScreen extends Component{
 render(){
   return(
     <View style={{flex:1 , justifyContent:'center', alignItems: "center"}}>
      <Text>MyDietScreen</Text>
     </View>
   )
 }

} 

