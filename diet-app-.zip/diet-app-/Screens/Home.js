import React, { Component } from 'react';
import {
  Text,
  View,
  StyleSheet,
  TouchableOpacity,
  Image,
  ImageBackground,
  SafeAreaView,
  Platform,
  StatusBar,
} from 'react-native';
import { NavigationContainer } from "@react-navigation/native";
import DrawerNavigator from "../Navigation/DrawerNavigatior";

import BalanceddietScreen from './Balanceddiet';
import MyDietScreen from './MyDiet';
import ProductsScreen from './Products';


export default class HomeScreen extends Component {
  render() {
    return (
    <NavigationContainer>
      <DrawerNavigator />
    </NavigationContainer>
     
    );
  }
}

