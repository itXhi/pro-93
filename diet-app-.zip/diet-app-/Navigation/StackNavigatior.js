import 'react-native-gesture-handler';
import * as React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import { createDrawerNavigator } from '@react-navigation/drawer';
import firebase from 'firebase';
import { firebaseConfig } from '../config';

 
import BalanceddietScreen from '../Screens/Balanceddiet';
import MyDietScreen from '../Screens/MyDiet';
import ProductsScreen from '../Screens/Products';


const Stack = createStackNavigator();

function App() {
  return (
   
      <Stack.Navigator  initialRouteName="Home"
      screenOptions={{
        headerShown: false
      }}
      >
      <Stack.Screen name="Balanceddiet" component={BalanceddietScreen} />
        <Stack.Screen name="MyDiet" component={MyDietScreen} />
        <Stack.Screen name="Products" component={ProductsScreen} />
      </Stack.Navigator>
  );
}



export default App;
