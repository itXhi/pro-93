
export const firebaseConfig = {
  apiKey: "AIzaSyAr1rowS-t3_8N7a4oRjK9cylqhtq9ciy4",
  authDomain: "diet-app-60e6d.firebaseapp.com",
  projectId: "diet-app-60e6d",
  storageBucket: "diet-app-60e6d.appspot.com",
  messagingSenderId: "730104478918",
  appId: "1:730104478918:web:7156b0980e5d9ff9a0ebc7"
};

