import 'react-native-gesture-handler';
import * as React from 'react';
import { createSwitchNavigator, createAppContainer } from "react-navigation";

import firebase from 'firebase';
import { firebaseConfig } from './config';

import { NavigationContainer } from '@react-navigation/native';

import LoadingScreen from './Screens/LoadingScreen'
import LoginScreen from './Screens/LoginScreen'
import HomeScreen from './Screens/Home'

if (!firebase.apps.length){
  firebase.initializeApp(firebaseConfig) 
}
else{
  firebase.app();
}

const AppSwitchNavigator = createSwitchNavigator({
  LoadingScreen: LoadingScreen,
  LoginScreen: LoginScreen,
  HomeScreen:HomeScreen,
});

const AppNavigator = createAppContainer(AppSwitchNavigator);

export default function App() {
  return <AppNavigator />;
}
